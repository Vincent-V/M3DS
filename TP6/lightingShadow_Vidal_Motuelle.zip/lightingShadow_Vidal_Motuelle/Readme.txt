Vidal Vincent
Motuelle Romain

Avancement :

Nous avons réussi l'ensemble des questions du TP Lighting Shadow.
