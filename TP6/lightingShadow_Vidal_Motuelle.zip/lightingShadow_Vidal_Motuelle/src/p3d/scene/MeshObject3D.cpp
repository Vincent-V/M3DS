#include "MeshObject3D.h"

using namespace p3d;

MeshObject3D::~MeshObject3D() {
}

MeshObject3D::MeshObject3D() {
}

