Motuelle Romain
Vidal Vincent

Avancement:

Nous avons réussi les 4 premiers exercices.
Cependant nous n'avons pas eu le temps de faire l'exercice 5.
