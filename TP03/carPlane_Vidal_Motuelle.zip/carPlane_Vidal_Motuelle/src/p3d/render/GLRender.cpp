#include "GLRender.h"
#include "Shader.h"
#include "Matrix3.h"
#include "Matrix4.h"
#include "Vector3.h"
#include "Tools.h"

#include <iostream>

/**

  @author F. Aubert
  @brief offers a (very) simple gl renderer for common operations (global projection, modelview, material, common shaders)
  **/

using namespace std;

namespace p3d {

static bool _isRenderInit=false;

Shader *_shader;
Matrix4 projectionMatrix;
Matrix4 modelviewMatrix;
Matrix4 textureMatrix;
Vector4 ambientColor;
Vector3 diffuseColor;
Vector3 specularColor;
vector<Vector4> lightPosition(4);
vector<float> lightIntensity(4);
int shininess;

Shader _shaderLightPhong;
Shader _shaderTextureLight;
Shader _shaderVertexAmbient;
Shader _shaderTextureAmbient;
Shader _shaderTexture3DAmbient;
Shader _shaderTexture4DAmbient;
Shader _shaderTextureDepth;

void initGLRender() {
  if (!_isRenderInit) {
    for(unsigned int i=0;i<lightPosition.size();++i) {
      lightPosition[i]=Vector4(0,0,1,0);
      lightIntensity[i]=0;
    }
    lightIntensity[0]=1;

    string savePath=p3d::mediaPath();
    p3d::mediaPath(string(RENDER_SHADER_PATH));
    _shaderLightPhong.attribute("position",0);
    _shaderLightPhong.attribute("normal",1);
    _shaderLightPhong.read("light_phong");

    _shaderTextureLight.attribute("position",0);
    _shaderTextureLight.attribute("normal",1);
    _shaderTextureLight.attribute("texCoord",2);
    _shaderTextureLight.read("texture_light");

    _shaderVertexAmbient.attribute("position",0);
    _shaderVertexAmbient.read("vertex_ambient");

    _shaderTextureAmbient.attribute("position",0);
    _shaderTextureAmbient.attribute("texCoord",2);
    _shaderTextureAmbient.read("texture_ambient");

    _shaderTexture3DAmbient.attribute("position",0);
    _shaderTexture3DAmbient.read("texture3D_ambient");

    _shaderTexture4DAmbient.attribute("position",0);
    _shaderTexture4DAmbient.attribute("texCoord",2);
    _shaderTexture4DAmbient.read("texture4D_ambient");

    _shaderTextureDepth.attribute("position",0);
    _shaderTextureDepth.attribute("texCoord",2);
    _shaderTextureDepth.read("texture_depth");


    modelviewMatrix.setIdentity();
    projectionMatrix.setIdentity();
    textureMatrix.setIdentity();
    lightPosition[0]=Vector4(0,0,0,1);
    _isRenderInit=true;
    p3d::mediaPath(savePath);
  }
}

void shaderLightPhong() {
  shader(&_shaderLightPhong);

  uniformTransformation();
  uniformMaterial();
  uniformLightPosition();
}

void shaderVertexAmbient() {
  shader(&_shaderVertexAmbient);
  _shader->uniform("mvp",projectionMatrix*modelviewMatrix);
  _shader->uniform("ambient",ambientColor);
}

void shaderTextureAmbient() {
  shader(&_shaderTextureAmbient);
  _shader->uniform("mvp",projectionMatrix*modelviewMatrix);
  _shader->uniform("textureMatrix",textureMatrix);
  _shader->uniform("ambient",ambientColor);
  _shader->uniform("texture0",0);
}

void shaderTexture3DAmbient() {
  shader(&_shaderTexture3DAmbient);
  _shader->uniform("mvp",projectionMatrix*modelviewMatrix);
  _shader->uniform("ambient",ambientColor);
  _shader->uniform("texture0",0);
}

void shaderTexture4DAmbient() {
  shader(&_shaderTexture4DAmbient);
  _shader->uniform("mvp",projectionMatrix*modelviewMatrix);
  _shader->uniform("ambient",ambientColor);
  _shader->uniform("texture0",0);
}


void shaderTextureDepth() {
  shader(&_shaderTextureDepth);
  _shader->uniform("mvp",projectionMatrix*modelviewMatrix);
  _shader->uniform("ambient",ambientColor);
  _shader->uniform("texture0",0);
}

void shaderTextureLight() {
  shader(&_shaderTextureLight);
  uniformTransformation();
  uniformLightPosition();
  _shader->uniform("textureMatrix",textureMatrix);
  _shader->uniform("texture0",0);
}

void uniformProjection() {
  _shader->uniform("projectionMatrix",projectionMatrix);
}

void uniformModelview() {
  _shader->uniform("modelviewMatrix",modelviewMatrix);
  _shader->uniform("normalMatrix",modelviewMatrix.normalMatrix());
}

void uniformTransformation() {
  uniformProjection();
  uniformModelview();
  uniformMVP();
}

void uniformMVP() {
  _shader->uniform("mvp",projectionMatrix*modelviewMatrix);
}

void uniformAmbient() {
  _shader->uniform("ambient",ambientColor);
}

void uniformAmbient(const Vector4 &c) {
  ambientColor=c;
  uniformAmbient();
}

void uniformMaterial() {
  _shader->uniform("ambient",ambientColor);
  _shader->uniform("material.diffuse",diffuseColor);
  _shader->uniform("material.specular",specularColor);
  _shader->uniform("material.shininess",shininess);
}

void uniformLightPosition() {
  for(unsigned int i=0;i<lightPosition.size();++i) {
    QString is=QString::number(i);
    // TODO : template this kind of thing
    _shader->uniform((QString("lightPosition[")+is+"]").toStdString(),lightPosition[i]);
    _shader->uniform((QString("lightIntensity[")+is+"]").toStdString(),lightIntensity[i]);
  }
}

void material(const p3d::Vector4 &ambient,const p3d::Vector3 &diffuse,const p3d::Vector3 &specular,int shininess) {
  p3d::ambientColor=ambient;p3d::diffuseColor=diffuse;p3d::specularColor=specular;p3d::shininess=shininess;
}

void materialBlueGreen() {
  material(Vector4(0,0.1,0.1,1),Vector3(0,0.3,0.7),Vector3(0,0.8,0.2),100);
}


void shader(Shader *s) {
  _shader=s;
  _shader->use();
}







} // namespace p3d

