Nom1 Prénom1
Nom2 Prénom2

Doit contenir :
- ce que vous avez fait.
- ce que vous n'avez pas fait (et pourquoi).
- difficultés rencontrées.
- commentaires éventuels sur le TP (points à éclaircir, longueur du sujet, etc). 
