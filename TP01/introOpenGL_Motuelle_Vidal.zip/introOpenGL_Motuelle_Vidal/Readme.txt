Binome : Motuelle Romain & Vidal Vincent

Achevement : 
- Nous avons répondu avec succès aux 24 premières questions. (Voir fichiers)
- Nous n'avons pas eu le temps de finir les 2 dernières questions. Car nous avons mis beaucoup plus de temps que prévu à installer Qt sur nos propres machines. (Ubuntu 12.04)

Difficultés rencontrées :
- Nous n'avons pas rencontré de difficultés particulières, le tout était bien expliqué et reprenait en grande partie ce qui avait été vu en cours.