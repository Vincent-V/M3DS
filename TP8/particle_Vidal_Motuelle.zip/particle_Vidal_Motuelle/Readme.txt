Vidal Vincent
Motuelle Romain

Avancement :

Le TP a été réalisé entièrement.

Le seul soucis apparait à la toute dernière question, lors de l'ajout de 4 nouveaux plans pour former une boite.
Le problème est que lorsque les sphères collisionnent ces nouveaux plans : elles rebondissent vers le haut.
Nous savons que le problème vient de la fonction Engine::collisionPlane qui ne prend pas en compte correctement la normale du plan. MAis nous ne sommes pas parvenu à corriger le problème.
