Vidal Vincent
Motuelle Romain

Avancement :
- La partie du TP sur Winged-Edges a été réalisé entièrement. La question Bonus (Q5) a aussi été faite.

Réponses au question :

Q3. En effet les normales des sommets du cube sont les bonnes.
Car on fait la moyenne des normales des 3 faces communes au sommet. 
Et on obtient une droite qui passerait par le sommet et le centre du cube.

Q4. En effet cela ne fonctionnait pas avec le bonhomme car celui ci comporte des bords au niveau du bas de son pantalon.
Il faut donc gérer le cas où lors d'un parcours, l'arête suivante n'xiste pas et vaut NULL.
Il faut dans ce cas remonter dans l'autre sens pour arriver de l'autre coté du bord.

Q5. Réussie
