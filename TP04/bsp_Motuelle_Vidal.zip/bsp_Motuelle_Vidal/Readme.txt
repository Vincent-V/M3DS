Vidal Vincent
Motuelle Romain

Avancement :

La partie du TP sur BSP a été réalisée entièrement, l'ensemble des questions ont été faites.
