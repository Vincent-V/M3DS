Vidal Vincent
Motuelle Romain

Avancement :

La partie du TP sur BSP a été réalisé jusqu'à l'exercice 4.
En effet nous ne sommes pas parvenu à terminer les dernières questions.
